from models.db import get_db

class Attendance:
    @staticmethod
    def mark(roll, date, status):
        db = get_db()
        cur = db.cursor()
        cur.execute(
            "INSERT INTO attendance (roll_no,date,status) VALUES (%s,%s,%s)",
            (roll, date, status)
        )
        db.commit()

    @staticmethod
    def percentage(roll):
        db = get_db()
        cur = db.cursor()

        cur.execute("SELECT COUNT(*) FROM attendance WHERE roll_no=%s", (roll,))
        total = cur.fetchone()[0]

        cur.execute(
            "SELECT COUNT(*) FROM attendance WHERE roll_no=%s AND status='Present'", (roll,))
        present = cur.fetchone()[0]

        return (present / total) * 100 if total > 0 else 0
