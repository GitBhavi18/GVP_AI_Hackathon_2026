from flask import Flask, render_template, request
from models.student import Student
from models.attendance import Attendance
from models.marks import Marks
from ai.ai_logic import attendance_warning, performance_remark

app = Flask(__name__)

# ---------------- HOME PAGE ----------------
@app.route("/")
def home():
    students = Student.get_all_students()
    return render_template("home.html", students=students)

# ---------------- ADD STUDENT ----------------
@app.route("/add_student", methods=["POST"])
def add_student():
    roll = request.form["roll"]
    if Student.exists(roll):
        return "Roll number already exists <br><a href='/'>Go Back</a>"

    Student.add_student(
        roll,
        request.form["name"],
        request.form["semester"]
    )
    return "Student Registered <br><a href='/'>Go Back</a>"

# ---------------- NAVIGATION PAGES ----------------
@app.route("/attendance")
def attendance_page():
    return render_template("attendance.html")

@app.route("/marks")
def marks_page():
    return render_template("marks.html")

@app.route("/report")
def report_page():
    return render_template("report.html")

# ---------------- ATTENDANCE SUBMIT ----------------
@app.route("/mark_attendance", methods=["POST"])
def mark_attendance():
    Attendance.mark(
        request.form["roll"],
        request.form["date"],
        request.form["status"]
    )
    return "Attendance Saved <br><a href='/attendance'>Go Back</a>"

# ---------------- MARKS SUBMIT ----------------
@app.route("/enter_marks", methods=["POST"])
def enter_marks():
    Marks.add_marks(
        request.form["roll"],
        request.form["subject"],
        request.form["marks"]
    )
    return "Marks Saved <br><a href='/marks'>Go Back</a>"

# ---------------- VIEW REPORT ----------------
@app.route("/view_report", methods=["POST"])
def view_report():
    roll = request.form["roll"]

    student = Student.get_by_roll(roll)
    if not student:
        return "Student not found <br><a href='/report'>Go Back</a>"

    attendance = Attendance.percentage(roll)
    avg = Marks.average(roll)

    remark = performance_remark(avg)
    warning = attendance_warning(attendance)

    return render_template(
        "report.html",
        student=student,
        attendance=attendance,
        avg=avg,
        remark=remark,
        warning=warning
    )

# ---------------- RUN APP ----------------
if __name__ == "__main__":
    app.run(debug=True)
